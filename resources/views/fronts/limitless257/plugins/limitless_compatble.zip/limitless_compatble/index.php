<?php 
/*
Plugin Name: Limitless Compatibility Plugin
Plugin URI: http://support.artillegence.com
Description: Add compatibility for versions below 2.0
Author: Abhin Sharma
Version: 1
Author URI: http://support.artillegence.com
*/

include_once('pui.php');
include_once('class_padmin_panel_maker.php');
include_once('lcomp.php');



if(!is_admin()) return;

class LimitlessBack extends PIOA_PANEL_CORE {
	

	
	// init menu
	function __construct () { parent::__construct( __('Limitless Compatibility','ioa'),'page','ltmbac');  }
	
	// setup things before page loads , script loading etc ...
	function manager_admin_init(){	

		if( isset($_GET['page']) && $_GET['page'] == "ltmbac" && isset($_GET['rcompat']) )
		{

			init_ioa_version_upgrade();

		}

	  }	
	
	
	/**
	 * Main Body for the Panel
	 */

	function panelmarkup(){	
		$ui = new PGlassUI();

		?>
		
		<div class="ioa_panel_wrap"> <!-- Panel Wrapper -->
			<div class=" clearfix">  <!-- Panel -->
        		<div id="option-panel-tabs" class="clearfix" data-shortname="<?php echo SN; ?>">  <!-- Options Panel -->

	                
                
                	<div id="panel-wrapper" class="clearfix ">
							<h4> If you are uprgading from version 1.5 or below please run this once. </h4>	
							<a class="button-default" style="display:block;padding:10px 20px;text-align:center;" href="<?php echo admin_url().'admin.php?page=ltmbac&rcompat=true' ?>" > Make Pages & Post Compatible </a>
						
					</div>	
                

            </div>
         </div>     </div>     	



		<?php
	

	    
	 }
	 

}

new LimitlessBack();