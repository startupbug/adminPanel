<?php

function init_ioa_version_upgrade()
{

		$old_css = '/* ============== CSS For RAD Widgets 1.0 Version / Remove When Not needed =========== */';
		
		$wp_query = new WP_Query(array(
				"post_type" => array('post','page'),
				'posts_per_page' => -1
			));
			while ( $wp_query->have_posts() ) : $wp_query->the_post();
	 			
	 				
	 					$data = get_post_meta(get_the_ID(),"rad_data",true);	
		 				if( isset($data[0]) && is_array($data) && $data!="" )
						{

							if(!isset($data[0]['data']))
							{
								$data = RADUpgrade($data,$styles);
								$data = base64_encode(addslashes(json_encode($data)));
								update_post_meta(get_the_ID(),"rad_data",$data);
							}
						}

			endwhile;
		
		// Setting Options
		

		$wp_query = new WP_Query(array(
				"post_type" => array('post','page','portfolio','testimonial'),
				'posts_per_page' => -1
			));
			while ( $wp_query->have_posts() ) : $wp_query->the_post();
	 			
	 				
	 					$ioa_options = get_post_meta(get_the_ID(),"ioa_options",true);	
		 				 if($ioa_options =="")
						 {
						  $old_values  = get_post_custom(get_the_ID());
						 
						  
						   foreach ($old_values as $key => $value) {
						    if($key!='rad_data' && $key!='rad_styler')
						    {
						      $ioa_options[$key] = $value[0];
						    }
						   }
						   update_post_meta(get_the_ID(),"ioa_options",$ioa_options);
						 } 


			endwhile; 
}

function PrimitiveRADStyler()
		{
			global $post;
			$styles = get_post_meta(get_the_ID(),"rad_styler_data",true);
			$style_code = '';
			
			if(!is_array($styles)) $styles = array();
			$uni_ar = array();
			foreach ($styles as $key => $style) {
				
				$style_data = $style_comps = array();
				
				if(isset($style['style_data']))
				$style_data = $style['style_data'];

				if(isset($style['style_comps']))
				$style_comps = $style['style_comps'];
				$style_data = getLCAssocMap($style_data,"value");


				unset($style_data['removable']);
				
				$style_code .= " #".$style['id']."{";

				foreach ($style_data as $key => $prop) {

				 if( isset($key) && $key!="" && $prop!="") :

				 		if($key=="background-image" )		
						{
							if(strpos($prop,"url") !== false) $style_code .= " ".$key.":".$prop."; ";
							else $style_code .= $prop;
						}
						else if($key=="padding" )
						{
							$style_code .= " padding-top:".$prop."; ";
							$style_code .= " padding-bottom:".$prop."; ";
						}	
						else
						{	
							$style_code .= " ".$key.":".$prop."; ";
						}

				 endif; 
				 		 
				}
				$style_code .= "}";

				foreach ($style_comps as  $prop) {
					
					if( isset($prop['value']) && $prop['value']!="" ) 	
					{

						if(isset($uni_ar["#".$style['id']." ".$prop['target']]))
							$prop['target'] .= " ".$prop['name'].":".$prop['value']."; ";
						else	
							$prop['target'] =  " ".$prop['name'].":".$prop['value']."; ";
					}
						 
				}

				
			}

			$fn_str = '';

				foreach ($uni_ar as $key => $value) {
					$fn_str .= $key."{ ".$value." } ";
				}
				
				$style_code .= $fn_str;
			
			echo "<style type='text/css'> $style_code </style>";

		}

add_action('wp_head','PrimitiveRADStyler');



function RADUpgrade($data,$styles ='')
{

	
	$sections = array();

	$def_sec_str = array(
		array( "name"=>"v_padding","value"=>""),
		array( "name"=>"classes","value"=>""),
		array( "name"=>"visibility","value"=>""),
		array( "name"=>"background_opts","value"=>""),
		array( "name"=>"background_color","value"=>" "),
		array( "name"=>"background_image","value"=>""),
		array( "name"=>"background_position","value"=>""),
		array( "name"=>"background_cover","value"=>""),
		array( "name"=>"background_repeat","value"=>""),
		array( "name"=>"background_attachment","value"=>""),
		array( "name"=>"background_gradient_dir","value"=>"horizontal"),
		array( "name"=>"start_gr","value"=>" "),
		array( "name"=>"end_gr","value"=>" "),
		array( "name"=>"video_url","value"=>""),
		array( "name"=>"border_top_width","value"=>"0"),
		array( "name"=>"border_top_color","value"=>" "),
		array( "name"=>"border_top_type","value"=>""),
		array( "name"=>"border_bottom_width","value"=>"0"),
		array( "name"=>"border_bottom_color","value"=>" "),
		array( "name"=>"border_bottom_type","value"=>"")
		);
	$def_cont_str = array(
		array( "name"=>"classes","value"=>""),
		array( "name"=>"visibility","value"=>""),
		array( "name"=>"background_opts","value"=>""),
		array( "name"=>"background_color","value"=>""),
		array( "name"=>"background_opacity","value"=>""),
		array( "name"=>"background_image","value"=>""),
		array( "name"=>"background_position","value"=>""),
		array( "name"=>"background_cover","value"=>""),
		array( "name"=>"background_repeat","value"=>""),
		array( "name"=>"background_attachment","value"=>""),
		array( "name"=>"background_gradient_dir","value"=>""),
		array( "name"=>"start_gr","value"=>""),
		array( "name"=>"end_gr","value"=>""),
		array( "name"=>"border_top_width","value"=>""),
		array( "name"=>"border_top_color","value"=>""),
		array( "name"=>"border_top_type","value"=>""),
		array( "name"=>"border_bottom_width","value"=>""),
		array( "name"=>"border_bottom_color","value"=>""),
		array( "name"=>"border_bottom_type","value"=>"")
		);

	$i =0;
	$filter_styles = array();

	if($styles!='')
	foreach($styles as $container)
	{
		if(isset($container['style_comps']))
		foreach ($container['style_comps'] as $key => $el) {

			if($el['name'] == 'background-color' && isset($el['value']))
			{
				$i = explode(' ',trim($el['target']));
				$filter_styles[$i[0]] = $el['value'];
			}
		}
				
		
	}

	 foreach ($data as $key => $section) {
	 	$containers = array();

	 	if(isset($section['components']))
	 	foreach ($section['components'] as $key => $widget) {
	 		$inps  = array();
	 		$test_center = false;

	 		foreach ($widget['inputs'] as $key => $value) {

	 			if($value['hidden']=='hide')
	 			{
	 				$inps[] = array('name' => $value['name'] , 'value' => '');	
	 			}
	 			else
	 			 {
	 			 	$temp = $value['value'];
	 			 	
	 			 	if($value['name'] == 'rad_tab') :
	 			 		$temp = str_replace("<titan_module>","[ioa_mod]",$w['rad_tab']);
						$temp = str_replace("<inp>","[inp]",$temp);
						$temp = str_replace("<s>","[ioas]",$temp);
						if(! strpos($temp, '<s>') ) $temp = str_replace(";","[ioas]",$temp);
					endif;

					$inps[] = array('name' => $value['name'] , 'value' => $temp);	
	 			 }	

	 			if($value['value'] == 'auto_align' && $value['name'] == 'float') 
	 			{
	 				$test_center = true;
	 			}

	 		}

	 		$fl = '';
	 		
	 		
			$def_cont_str = array(
				array( "name"=>"classes","value"=>""),
				array( "name"=>"visibility","value"=>""),
				array( "name"=>"background_opts","value"=>""),
				array( "name"=>"background_color","value"=>""),
				array( "name"=>"background_opacity","value"=>""),
				array( "name"=>"background_image","value"=>""),
				array( "name"=>"background_position","value"=>""),
				array( "name"=>"background_cover","value"=>""),
				array( "name"=>"background_repeat","value"=>""),
				array( "name"=>"background_attachment","value"=>""),
				array( "name"=>"background_gradient_dir","value"=>""),
				array( "name"=>"start_gr","value"=>""),
				array( "name"=>"end_gr","value"=>""),
				array( "name"=>"border_top_width","value"=>""),
				array( "name"=>"border_top_color","value"=>""),
				array( "name"=>"border_top_type","value"=>""),
				array( "name"=>"border_bottom_width","value"=>""),
				array( "name"=>"border_bottom_color","value"=>""),
				array( "name"=>"border_bottom_type","value"=>"")
				);
	 		
	 		

			if( isset($filter_styles['#'.$widget['id']]) && $filter_styles['#'.$widget['id']] != 'transparent' && $widget["type"] == 'Text' )
			{
				
				$def_cont_str = array(
					array( "name"=>"classes","value"=>""),
					array( "name"=>"visibility","value"=>""),
					array( "name"=>"background_opts","value"=>"bg-color"),
					array( "name"=>"background_color","value"=>$filter_styles['#'.$widget['id']]),
					array( "name"=>"background_opacity","value"=>""),
					array( "name"=>"background_image","value"=>""),
					array( "name"=>"background_position","value"=>""),
					array( "name"=>"background_cover","value"=>""),
					array( "name"=>"background_repeat","value"=>""),
					array( "name"=>"background_attachment","value"=>""),
					array( "name"=>"background_gradient_dir","value"=>""),
					array( "name"=>"start_gr","value"=>""),
					array( "name"=>"end_gr","value"=>""),
					array( "name"=>"border_top_width","value"=>""),
					array( "name"=>"border_top_color","value"=>""),
					array( "name"=>"border_top_type","value"=>""),
					array( "name"=>"border_bottom_width","value"=>""),
					array( "name"=>"border_bottom_color","value"=>""),
					array( "name"=>"border_bottom_type","value"=>"") 
					);
			}
			if($test_center) $def_cont_str[] = array("name" =>"float","value"=>"auto_align");	 				

	 		$widgets = array( array( "id" => $widget['id'] , "data" => $inps , "type" => toRADV2Key($widget["type"]) ) );
	 		$containers[] = array( "id" => "rpc".$widget['id'] , "data" => $def_cont_str , "layout" => toRADV2Layout($widget['layout']) , "widgets" => $widgets );
	 	}
	 	

	 	if(isset($section['id']))
	 	{
	 		$sid = $section['id'];
	 	}
	 	else
	 		$sid = 'rps'.uniqid();


	 	$sections[] = array( "id" => $sid , "data" => $def_sec_str , "containers" => $containers );
	 	$i++;
	 }
	return $sections; 

}

function toRADV2Layout($str)
{
	$t = 'full';
	switch($str)
	{
		case '20%' : $t = 'one_fifth'; break;
		case '25%' : $t = 'one_fourth'; break;
		case '33%' : $t = 'one_third'; break;
		case '50%' : $t = 'one_half'; break;
		case '66%' : $t = 'two_third'; break;
		case '75%' : $t = 'three_fourth'; break;
		case '80%' : $t = 'four_fifth'; break;
		case '100%' : $t = 'full'; break;
		case 'full-width' : $t = 'full'; break;
	}

	return $t;

}

function toRADV2Key($type)
{

	$t = '';

	switch($type)
	{
		case 'Text' : $t = 'rad_text_widget'; break;
		case 'Sidebar' : $t = 'rad_sidebar_widget'; break;
		case 'Gallery' : $t = 'rad_gallery_widget'; break;
		case 'Post_List' : $t = 'rad_post_list_widget'; break;
		case 'Post_Grid' : $t = 'rad_post_grid_widget'; break;
		case 'Post_Slider' : $t = 'rad_post_slider_widget'; break;
		case 'Intro_Title' : $t = 'rad_intro_widget'; break;
		case 'CTA' : $t = 'rad_cta_widget'; break;
		case 'Accordion' : $t = 'rad_accordion_widget'; break;
		case 'Tabs' : $t = 'rad_tabs_widget'; break;
		case 'Props' : $t = 'rad_prop_widget'; break;
		case 'Image' : $t = 'rad_image_widget'; break;
		case 'Divider' : $t = 'rad_divider_widget'; break;
		case 'Scrollable' : $t = 'rad_scrollable_widget'; break;
		case 'Testimonials' : $t = 'rad_testimonials_widget'; break;
		case 'Testimonial_Bubble' : $t = 'rad_testimonial_widget'; break;
		case 'Video' : $t = 'rad_video_widget'; break;
		case 'Pie_Chart' : $t = 'rad_piechart_widget'; break;
		case 'Bar_Graph' : $t = 'rad_bargraph_widget'; break;
		case 'Line_Graph' : $t = 'rad_linegraph_widget'; break;
		case 'Doughnut_Chart' : $t = 'rad_doughnut_widget'; break;
		case 'Progress_Bar' : $t = 'rad_progressbar_widget'; break;
		case 'Radial_Chart' : $t = 'rad_radial_widget'; break;
		case 'Stacked_Circle' : $t = 'rad_stackcircle_widget'; break;
		case 'Person' : $t = 'rad_teamwidget_widget'; break;

	}

	return $t;
}

 function getLCAssocMap($inputs,$key,$noempty=false)
 {
 	$arr = array();
 	if(is_array($inputs))
 	{
 		foreach($inputs as $input)
		{
			if(isset( $input[$key]))
				{
					if( $noempty)
						{
							if(trim( $input[$key])!="")
							$arr[$input['name']] =   stripslashes($input[$key]);
						}
					else
					{
						if(isset($input['name'])) $arr[$input['name']] =    stripslashes($input[$key]);
					}	
				}
			else
				$arr[$input['name']] =   false;	
		}
 	}
	return $arr;	
 }	

add_action( 'wp_enqueue_scripts', 'add_ioa_old_icons', 99 );
function add_ioa_old_icons() {

	wp_enqueue_style('old-ioa-fontawesome',WP_PLUGIN_URL.'/limitless_compatble/old_icons/font-awesome.css');
  
}