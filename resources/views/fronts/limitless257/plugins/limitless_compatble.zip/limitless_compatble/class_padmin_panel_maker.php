<?php
/**
 *  Base Class for creating admin panels.
 *  Version : 3.1
 *  Dependency : None
 */

$ioa_page_get = '';

if(isset($_GET['page']))
$ioa_page_get =  $_GET['page']; // In class scope it points to Inherited class

if(!class_exists('PIOA_PANEL_CORE')) {

// == Class defination begins	=====================================================
  
  class PIOA_PANEL_CORE {
	  
	  private $name;
	  private $panelName;
	  private $type;
	  private $icon;
	  private $role;

	  private $tabs;

	  private $topBar = true;
	  private $isCustom = false;
	 /**
	  *  Constrtuctor For Admin Maker 
	  *  @param string $name The Name of the Panel that will Appear in WP ADMIN side menu
	  *  @param string $type Type of Menu Defautl Page(Separate Menu) , supported values are page and submenu
	  *  @param string $panel_name	unique key name for panel( ex : admin.php?page=ULT ). Defaults to first 5 letters in capital.
	  *  @param string $icon The link to icon , set to false to use wp default icon. 
	  *  @param string $role The role/level required to access the panel. 
	  */
	 
      function __construct($name,$type='page',$panel_name=false, $icon = false,$role = 'edit_theme_options') { 
	  
		$this->name = $name;
		$this->tabs = array();
		if(!$panel_name)
			$this->panelName = strtolower(substr($name,0,5));
		else
			$this->panelName = 	$panel_name;
		
		$this->type = $type;
		
	
			$this->icon = NULL;
		
		$this->role= $role;

		add_action('admin_menu',array(&$this,'manager_admin_menu'));
        add_action('admin_init',array(&$this,'manager_admin_init'));
		
	  }

	  function disableTopBar()
	  {
	  	$this->topBar = false;
	  }
	  
	  function isCustomPanel($bool)
	  {
	  	$this->isCustom = $bool;
	  }
	  function manager_admin_menu(){
		
		  
	   	switch($this->type)
	   	{
		   case 'page' : add_menu_page( $this->name,  $this->name , $this->role, $this->panelName ,array($this,'manager_admin_wrap'),  $this->icon);  break;
		   case 'submenu':  add_submenu_page("ioa", $this->name, $this->name, $this->role, $this->panelName ,array($this,'manager_admin_wrap')); break;
		   case 'null':  add_submenu_page(null, $this->name, $this->name, $this->role, $this->panelName ,array($this,'manager_admin_wrap')); break;
	   	}
		  
				  
	  }
		  
	  function manager_admin_init(){	
	 	 
	  
	    }	
	  
	  function panelmarkup() { }

	
	  /**
	   * Add a Vertical Tab
	   * @param array get Tab data
	   */
	  
	  public function addTab($tab)
	  {
	  	$this->tabs[] = $tab;
	  }

	  public function getTabs()
	  {
	  	$str = '<div class="ioa_tabs">';

	  	/**
	  	 * Make Tab Index
	  	 */
	  	$str .= "<ul class='ioa_tab_index'>";
	  	foreach($this->tabs as $tab)
	  	{
	  		$key = str_replace(" ","_",trim($tab['label']));
	  		$str .= "<li><a href='#{$key}'>".$tab['label']."</a></li>";
	  	}
	  	$str .= "</ul>";
	  	

	  	/**
	  	 * Tab Content
	  	 */
	  	
	  	foreach($this->tabs as $tab)
	  	{
	  		$key = str_replace(" ","_",trim($tab['label']));
	  		$str .= "<div class='ioa_tab_content' id='{$key}'>".$tab['html']."</div>";
	  	}

	  	$str .= "</div>";
	  	return $str;

	  }

	   function manager_admin_wrap(){	
            global $ioa_page_get;
            ?>

            <div class="ioa_wrap">

            	<div class="ioa-message">
		        
		          <div class="ioa-message-body">
		                <p><?php _e('Settings Saved !','ioa') ?></p>
		              
		          </div>
		        </div>

        	

			<div class="clearfix <?php if(!$this->isCustom) echo 'ioa_admin_panel'; ?>"> 
				<span class="waiting"></span>
            	<?php $this->panelmarkup() ; ?>
            </div>
			
			</div> <!-- End of Framework Panel -->
            <?php

	   }	  
	  
	 
 	} // == End of Class ==========================
     
	 
	
}
